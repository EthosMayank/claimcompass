const BASE_URL='https://preview.radicle.co.in/calmcampus/';
// const BASE_URL='http://localhost/';
function toggleAccordion(header) {
    const content = header.nextElementSibling;
    const icon = header.querySelector('span');
    const isVisible = content.style.display === 'block';

    document.querySelectorAll('.accordion-content').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.accordion h3 span').forEach(sp => sp.innerText = '➕');

    if (!isVisible) {
      content.style.display = 'block';
      icon.innerText = '➖';
    }
  }

  function toggleMenu() {
    const nav = document.getElementById('mobileNav');
    nav.classList.toggle('show');
  }


  document.getElementById('contact-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);

    const data = {
      name: formData.get('name'),
      email: formData.get('email'),
      roleorcompany: formData.get('roleorcompany'),
      message: formData.get('message'),
    };

    try {
      const response = await fetch('/contact/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (response.ok) {
        form.reset(); document.getElementById('thankYouPopup').style.display = 'flex';
      } else {
        alert('Something went wrong. Please try again later.');
      }
    } catch (err) {
      console.error(err);
      alert('Failed to send message...Retry!');
    }
  });





  if(BASE_URL!='http://localhost/'){
    // Disable right-click context menu
    document.addEventListener('contextmenu', event => event.preventDefault());

    // Disable common keyboard shortcuts
    document.addEventListener('keydown', function (event) {
      // F12
      if (event.key === "F12") {
        event.preventDefault();
      }
  
      // Ctrl+Shift+I / J / C / U
      if (event.ctrlKey && event.shiftKey && (
          event.key === 'I' || 
          event.key === 'J' || 
          event.key === 'C'
      )) {
        event.preventDefault();
      }
  
      // Ctrl+U
      if (event.ctrlKey && event.key === 'u') {
        event.preventDefault();
      }
  
      // Cmd+Opt+I/J on Mac
      if ((event.metaKey && event.altKey) && (
          event.key === 'I' || 
          event.key === 'J'
      )) {
        event.preventDefault();
      }
    });
  
    // Optional: detect if devtools are open via size-check (not 100% reliable)
    setInterval(function () {
      if (
        window.outerWidth - window.innerWidth > 160 || 
        window.outerHeight - window.innerHeight > 160
      ) {
        // document.body.innerHTML = "<h1 style='text-align:center;margin-top:20%;color:red;'>DevTools Detected. Access Denied.</h1>";
      }
    }, 1000);
  }

