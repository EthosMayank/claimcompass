<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(){
        $slides=[
            ['ID'=>1,'HEAD'=>'Smarter Claim Tracking in One View','IMAGE'=>base_url('assets/img/CC-Compass-1.png'),'DESCRIPTION'=>'Stay on top of your workload <br/> with a visual pipeline. Easily <br/> review claim status, value, and <br/> stage in one clean interface.'],
            ['ID'=>2,'HEAD'=>'Perfect for Independent Adjusters','IMAGE'=>base_url('assets/img/Black-briefcase-freepik.png'),'DESCRIPTION'=>'Claim Compass empowers <br/> adjusters and small teams to <br/> stay organized and responsive, <br/> enabling them to manage more <br/> claims with confidence.'],
            ['ID'=>3,'HEAD'=>'Automated Reminders That Work','IMAGE'=>base_url('assets/img/CC-Calendar-2.png'),'DESCRIPTION'=>'Trigger follow-ups automatically <br/> as claims move forward. Stay <br/> timely and reduce the need for <br/> manual check-ins.'],
            ['ID'=>4,'HEAD'=>'Simple Workflow Controls','IMAGE'=>base_url('assets/img/CC-Controller-1.png'),'DESCRIPTION'=>'Quickly assign teammates, filter <br/> by platform, and adjust claim <br/> stages. Everything feels natural <br/> and easy to manage.'],
        ];
        $page_data=[
            'page_title'=>'Welcome to Claim Compass','page_meta'=>[false, false],'page_keywords'=>'Claim Management, Public Adjusters CRM, Insurance Claims, Workflow Automation, Adjuster Software, Claims Tracker','page_description'=>'Claim Compass is a powerful, simple-to-use CRM designed specifically for public adjusters. Track claims, automate workflows, and stay organized.','slides'=>$slides
        ];
        return view('home',$page_data);
    }
    public function faqs(){
        $faqs=[
            ['ID'=>1,'QUESTION'=>'What is a public adjuster CRM?','ANSWER'=>'A public adjuster CRM is a specialized software tool designed to assist claims professionals in managing every step of the claims process. Unlike general-purpose CRMs, it helps organize files, track claim status, automate tasks, and minimize repetitive administrative work, allowing adjusters to stay focused on resolution.'],
            ['ID'=>2,'QUESTION'=>'What features are included in a CRM for public adjusters?','ANSWER'=>'Most public adjuster CRMs include essential tools designed to facilitate daily workflows:
        <ul>
          <li><strong>Client Management:</strong> Organize contacts, policy information, and communication history to streamline operations.</li>
          <li><strong>Claims Tracking:</strong>  Track the status of claims, tasks, and important deadlines.</li>
          <li><strong>Document Storage:</strong>  Store all files related to claims in a single secure location.</li>
          <li><strong>Task Automation:</strong>   Initiate reminders, follow-ups, and scheduling actions.</li>
          <li><strong>Reporting Tools:</strong>  Create summaries of claims performance and financials.</li>
          <li><strong>Integrations:</strong>  Connect with email, calendars, and accounting platforms such as Xactimate and QuickBooks.</li>
        </ul>'],
            ['ID'=>3,'QUESTION'=>'How is a public adjuster CRM different from a traditional CRM?','ANSWER'=>'<p>Traditional Customer Relationship Management (CRM) systems are typically designed for sales and customer service teams.
</p><p> A public adjuster CRM is specifically designed for the claims lifecycle, providing tools for documentation, inspections, settlement tracking, and workflow management tailored to the practical needs of public adjusters.</p>'],
            ['ID'=>4,'QUESTION'=>'Can a CRM genuinely replace spreadsheets or project management tools?','ANSWER'=>'<p>Yes, spreadsheets and tools such as Spreadsheets or Trello can be helpful initially; however, they do not provide the required structure and automation for handling high volumes of claims.
</p><p>A dedicated CRM simplifies tracking, automates repetitive tasks, and offers a clear pipeline view, enabling adjusters to stay organized and efficient.</p>'],
            ['ID'=>5,'QUESTION'=>'Do public adjusters require a dedicated CRM?','ANSWER'=>' Absolutely. Adjusters face unique workflow demands, documentation requirements, and time-sensitive claims. A dedicated CRM helps you remain organized, compliant, and responsive to each claim without having to rely on patchwork tools.
'],
            ['ID'=>6,'QUESTION'=>'How does a CRM help during storm or CAT events?','ANSWER'=>'During high-volume events, such as hurricanes or hailstorms, a CRM helps adjusters manage multiple claims efficiently by automating follow-ups, scheduling, and document handling, thereby reducing the time wasted on manual tasks.'],
            ['ID'=>7,'QUESTION'=>'Is Claim Compass compliant with industry data security standards?','ANSWER'=>' Claim Compass employs industry-grade security protocols to safeguard sensitive claim data, ensuring that all documents, notes, and communications are secure and encrypted.
'],
            ['ID'=>8,'QUESTION'=>'Does a CRM improve team communication and collaboration?','ANSWER'=>'Yes, team members can allocate tasks, collaborate on notes, and monitor claim statuses through a single dashboard, ensuring everyone stays coordinated without the need for repetitive emails or redundant efforts.'],
            ['ID'=>9,'QUESTION'=>'What types of reports can I generate with a CRM?','ANSWER'=>'Integrated reporting tools help you track performance and streamline your processes. You can monitor claim volume, timelines, settlement rates, team productivity, and more, coming soon.'],
            ['ID'=>10,'QUESTION'=>'What is the cost associated with Claim Compass?','ANSWER'=>'<p>Claim Compass offers a comprehensive plan that provides public adjusters complete access to all features. Pricing is transparent and adjusts according to team size.</p>
    <p>A <strong>free two-week trial</strong> is available for exploring the platform.</p>
'],
            ['ID'=>11,'QUESTION'=>'Are there any hidden fees?','ANSWER'=>'No, Claim Compass pricing is flexible, ensuring that there are no surprise charges or feature restrictions. You pay for what you get, and discounts are available based on user volume.'],
        ];
        $page_data=[
            'page_title'=>'FAQs | Claim Compass','page_meta'=>[false, false],'page_keywords'=>'Ask Claim Management, Ask Public Adjusters CRM, Ask Insurance Claims, Ask Workflow Automation, Ask Adjuster Software, Ask Claims Tracker','page_description'=>'Claim Compass is a powerful, simple-to-use CRM designed specifically for public adjusters. Track claims, automate workflows, and stay organized.','faqs'=>$faqs,
        ];
        return view('faqs',$page_data);
    }
    public function contact(){
        $page_data=[
            'page_title'=>'Contact | Claim Compass','page_meta'=>[false, false],'page_keywords'=>'Contact Claim Management, Contact Public Adjusters CRM, Contact Insurance Claims, Contact Workflow Automation, Contact Adjuster Software, Contact Claims Tracker','page_description'=>'Claim Compass is a powerful, simple-to-use CRM designed specifically for public adjusters. Track claims, automate workflows, and stay organized.'
        ];
        return view('contact',$page_data);
    }
    public function contactSubmit(){
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403)->setJSON(['error' => 'Forbidden access']);
        }

        helper(['security', 'text']);

        $validation = \Config\Services::validation();

        $data = $this->request->getJSON(true);

        $rules = [
            'name'    => 'required|min_length[2]|max_length[100]',
            'email'   => 'required|valid_email|max_length[255]',
            'roleorcompany'   => 'required|max_length[100]',
            'message' => 'required|min_length[5]|max_length[1000]'
        ];

        if (!$validation->setRules($rules)->run($data)) {
            return $this->response
                ->setStatusCode(422)
                ->setJSON(['errors' => $validation->getErrors()]);
        }

        // Sanitize manually if needed
        $name    = esc($data['name']);
        $email   = esc($data['email']);
        $roleorcompany   = esc($data['roleorcompany']);
        $message = esc($data['message']);

        if (preg_match("/[\r\n]/", $name . $email . $roleorcompany)) {
            return $this->response->setStatusCode(400)->setJSON(['error' => 'Invalid input detected']);
        }

        // Prepare and send the email
        $emailService = \Config\Services::email();

        $emailService->setTo('testmancontact@gmail.com');//Info@claimcompasscrm.com
        $emailService->setFrom('Info@claimcompasscrm.com', 'Contact Form Lead');
        $emailService->setSubject('New Contact Form Submission');
        $emailService->setMessage(
            "Name: $name\nEmail: $email\nRole or Company: $roleorcompany\n\nMessage:\n$message"
        );
        mail('testmancontact@gmail.com', 'Test Mail', 'If you receive this, mail() works!');
        

        if (!$emailService->send()) {
            log_message('error', $emailService->printDebugger(['headers', 'subject', 'body']));
            return $this->response->setStatusCode(500)->setJSON(['error' => 'Failed to send email.']);
        }

        return $this->response->setStatusCode(200)->setJSON(['status' => 'success']);
    }
}
