<?php $page_data=['page_title'=>$page_title??env("APP_NAME"),'page_menu'=>$page_menu??false,'page_sidemenu'=>$page_sidemenu??false];$this->extend('master-layouts/main-section',$page_data); ?>
<?=$this->section('content') ?>



<section class="faq-wrapper mt-1 mb-5">
  <div class="faq-header">
    <h1>Confident Moves Start with the Right Answers</h1>
    <p class="subtext mt-1">Your FAQ for Choosing the Right CRM with Clarity and Confidence.</p>
    <img src="<?=base_url('assets/img/Magnifying glass.png');?>" alt="FAQ icon" class="faq-icon"/>
    <p class="description mt-1">
      Feeling overwhelmed by spreadsheets or dealing with incompatible tools? Claim Compass is the perfect CRM designed specifically for adjusters: it’s user-friendly, smart, and available whenever you need it!
    </p>
    <strong>You have questions.<br>Here, you will find clear and practical answers.</strong>
  </div>

  <div class="faq-list mt-6"><?php if(isset($faqs)&&is_array($faqs)){ $f=0; foreach($faqs as $faq){ $f++; ?>
    <div class="faq-item">
      <button class="faq-question">
        <?=$faq['QUESTION'];?>
        <span class="faq-icon-toggle <?=$f==1?'icon-minus':'icon-plus';?>"></span>
      </button>
      <div class="faq-answer<?=$f==1?' open':'';?>">
        <?=$faq['ANSWER'];?>
      </div>
    </div><?php }} ?>
  </div>
</section>






<script>
document.querySelectorAll('.faq-question').forEach((btn) => {
  btn.addEventListener('click', () => {
    const answer = btn.nextElementSibling;
    const icon = btn.querySelector('.faq-icon-toggle');

    const isOpen = answer.classList.contains('open');

    // Collapse all other answers
    document.querySelectorAll('.faq-answer').forEach(el => el.classList.remove('open'));
    document.querySelectorAll('.faq-icon-toggle').forEach(el => {
      el.classList.remove('icon-minus');
      el.classList.add('icon-plus');
    });

    // Toggle current one
    if (!isOpen) {
      answer.classList.add('open');
      icon.classList.remove('icon-plus');
      icon.classList.add('icon-minus');
    }
  });
});


</script>






<?=$this->endSection();?>