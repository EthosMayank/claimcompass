<?php $page_data=['page_title'=>$page_title??env("APP_NAME"),'page_menu'=>$page_menu??false,'page_sidemenu'=>$page_sidemenu??false];$this->extend('master-layouts/main-section',$page_data); ?>
<?=$this->section('content') ?>



  <section class="hero mt-2">
    <h1>Claim Compass</h1>
    <h2>Built for the way you actually work.<br>Your claims process is guided with <br/>clarity and ease.</h2>
    <p class="mt-3">Public Adjuster CRM designed to feel like the tool you’ve  <br/>always wanted. It’s clean, powerful, and effortless to use.</p>
    <div class="justify-center mt-2"><a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Sign up Today</a></div>
    <img src="<?=base_url('assets/img/image 1.png');?>" alt="CRM Screenshot" class="mt-3"/>
    <p class="fs-1">Claim Compass is a streamlined claims management software that simplifies claim  <br/>tracking and enhances team visibility. It allows for efficient and distraction-free  <br/>insurance claims management.</p>
    <strong class="fs-1">Thoughtfully designed to help you move every claim forward.</strong><br><br>
    <div class="justify-center"><a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Get Access Now</a></div>
  </section>


  <section class="section built-for-adjusters mt-5">
  <h1>Built for Public Adjusters</h1>
  <p class="subtitle">
    Claim Compass combines minimalist design with advanced functionality to transform  <br/>how adjusters manage claims.
    It’s intuitive, efficient, and designed to support the real  <br/>pace and structure of your workflow.
  </p>

  <h2 class="highlight-heading">Here’s what sets it apart:</h2>

  <div class="features-grid">
    <div class="feature-item">
      <img src="<?=base_url('assets/icons/CC-Phone-Gps-Route 1.svg');?>" alt="Visual Pipeline" width="140"/>
      <h3>Visual Pipeline</h3>
      <p>That makes every stage of your claims process easy to understand and manage.</p>
    </div>
    <div class="feature-item">
      <img src="<?=base_url('assets/icons/Cork Board.svg');?>" alt="Team Visibility" width="150"/>
      <h3>Team Visibility and Smart Access Control</h3>
      <p>So everyone stays aligned without confusion.</p>
    </div>
    <div class="feature-item">
      <img src="<?=base_url('assets/icons/Gear.svg');?>" alt="Intelligent Automation" width="116"/>
      <h3>Intelligent Automation</h3>
      <p>That keeps claims moving without adding friction or complexity.</p>
    </div>
  </div>

  <h2 class="final-heading mt-5">
    Easy to adopt. Quick to navigate.<br />
    Built to help adjusters do their best  <br/>work.
  </h2>
  <div class="mt-2"><a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Sign up Today</a></div>
  </section>



  <!-- Benefits Section -->
  <section class="section claim-benefits mt-5">
    <div class="benefits-container">
      <div class="benefits-left">
        <h2>Built to Handle Claims with Clarity and Control</h2>
        <p>
          Every feature is thoughtfully placed to help you stay organized, act quickly, and stay in control at every
          stage of the claims process.
        </p>
        <div class="mt-1"><strong>Everything is connected. Everything makes sense.</strong></div>
      </div>
      <div class="benefits-right list">
        <h3>Everything You Need to Work Smarter Today</h3>
        <ul>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> <strong>Two-week free trial with no signup fee</strong></li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> No contracts, cancel anytime</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Up to 10K monthly inbound and outbound emails</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> 1 TB document storage for up to 5 years of claims history</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Access optimized for desktop, tablet, and mobile</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Built-in calendar and email integration</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Smart automations to improve speed and consistency</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> AI-powered document reader for faster claim processing</li>
        </ul>
      </div>
    </div>

    <hr class="divider" />

    <p class="bottom-note fs-20 fw-700 text-dark">
      Claim Compass gives you the freedom to work according to your preferences today, while the necessary tools for tomorrow are already in motion.
    </p>

    <div class=" mt-2"><a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Sign up Today</a></div>
  </section>



  <!-- Automation Section -->
  <section class="section automation mt-5">
  <h2>Automation That Speeds Up Every Step</h2>
  <img src="<?=base_url('assets/img/CC-3d-robot-hand-with-thumb-up-gesture 1.png');?>" alt="Automation Icon" class="automation-icon" width="120" />
  <h3>Smart triggers. Fewer clicks. Better communication.</h3>
  <p>
    Claim Compass includes built-in automation designed for public adjusters. As claims <br/>progress through stages—
    such as inspection to appraisal—emails are generated  <br/>instantly and are ready to be sent.
    It’s a simple, effective way to stay responsive  <br/>without breaking your flow.
  </p>
  <strong class="mt-1">
    With just one click, you keep clients and stakeholders informed without disrupting  <br/>your day.
  </strong>

  <h4 class="mt-3">What Smart Automation Looks Like</h4>

  <div class="automation-cards">
    <div class="auto-card">
      <img src="<?=base_url('assets/img/CC-Mail-Neon-Red.png');?>" alt="Email Icon" width="140" />
      <h5>Trigger-Based Emails</h5>
      <p>
        Advance a claim and automatically generate the right message, just press send.
      </p>
    </div>
    <div class="auto-card mt-neg-2">
      <img src="<?=base_url('assets/img/CC-Ruler-1.png');?>" alt="Workflow Icon" width="100" />
      <h5>Custom Workflow Rules</h5>
      <p>
        Establish your automation once, and it will match your team's actual process.
      </p>
    </div>
    <div class="auto-card mt-neg-2">
      <img src="<?=base_url('assets/img/CC-Check-Phone.png');?>" alt="Sync Icon" width="100" />
      <h5>Always In-Sync</h5>
      <p>
        Automation lives inside your pipeline, so your outreach always aligns with progress.
      </p>
    </div>
  </div>

  <h3 class="highlight">Automation is fully integrated into <br/>Claim Compass to help you stay <br/> ahead with less effort and greater <br/> impact.</h3>

  <div class=" mt-3"><a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Sign up Today</a></div>
</section>



<!-- Upcoming Tools -->
<section class="section upcoming-tools mt-5 p-0">
  <div class="tools-container">
    <div class="tools-left">
      <div class="tools-overlay">
        <h2>We’re investing in<br />tomorrow!</h2>
        <p>
          Claim Compass is constantly improving to stay ahead of the curve in claims management.
          Our development team actively listens to feedback from public adjusters and translates those
          insights into powerful, practical tools.
        </p>
      </div>
    </div>
    <div class="tools-right list">
      <h3>Innovative Tools Under<br />Development Arriving Soon</h3>
      <ul>
        <li> <span class="icon-tick icon-circle icon-gray not-before">&nbsp;</span> Integrated e-signature workflows for faster approvals</li>
        <li> <span class="icon-tick icon-circle icon-gray not-before">&nbsp;</span> Admin-level accounts for office staff</li>
        <li> <span class="icon-tick icon-circle icon-gray not-before">&nbsp;</span> Roof sketch (ESX) reports are available in-platform</li>
        <li> <span class="icon-tick icon-circle icon-gray not-before">&nbsp;</span> AI conversion from PDF to ESX</li>
        <li> <span class="icon-tick icon-circle icon-gray not-before">&nbsp;</span> Advanced Xactimate integration</li>
        <li> <span class="icon-tick icon-circle icon-gray not-before">&nbsp;</span> Route tracking and mileage reporting for field efficiency</li>
      </ul>
    </div>
  </div>
</section>


<!-- Pricing -->
<section class="section pricing mt-5">
  <h2>Simple pricing. Full access. No surprises.</h2>
  <p>
    Claim Compass operates with a single, robust plan that features no tiers or locked <br/> features.
    You receive everything from the start, including a <strong><i>free two-week trial</i></strong> to test <br/> it out.
    When we launch new features, optional upgrades will be offered.
  </p>
  <div class="mt-1"><strong>The more users you invite, the greater your discount will be.</strong></div>

  <div class="section-pricing">
    <div class="pricing-box">
      <div class="price-left list">
        <h3><span class="price-now">$129</span> <span class="price-old">$249</span>/month</h3>
        <ul>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span>  <strong>Full access to All Features</strong></li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span>  Priority support</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span>  API access</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span>  Integrations</li>
          <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span>  Account manager</li>
        </ul>
      </div>
      <div class="price-line"></div>
      <div class="price-right">
        <div class="mob-top-right mb-4"><span class="tag">Launch Special</span></div>
        <p>
          Best for 2–10 user firms led by hands-on owners needing simplicity, scale, and automation.
        </p>
        <div class="mt-3"><a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Get Started</a></div>
        <div class="small mt-1"><i>For individual use only.</i></div>
      </div>
    </div>
  </div>
</section>



<!-- Features -->
<section class="section claim-features mt-5">
  <h2>What’s Inside Claim Compass<br>that Moves Claims Forward</h2>

  <div class="features-box list">
    <ul class="feature-list">
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Up to 50 contracts</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Claims tracking</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Xactimate sync</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Automated reminders</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Advanced reporting</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Priority support</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Custom workflow automation</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> API access</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Custom integrations</li>
      <li><span class="icon-tick icon-bg-dark icon-white icon-circle not-before">&nbsp;</span> Dedicated account manager</li>
    </ul>
    <img src="<?=base_url('assets/icons/ICON.svg');?>" alt="Claim Compass Logo" class="logo-icon">
  </div>

  <div class="">
    <div class="cta-btn">
      <a href="https://claimcompasscrm.com/signup" target="_BLANK" class="btn-primary bs-theme">Sign up Today</a>
    </div>
  </div>
</section>



<!-- Slideshow -->
 <section class="section claim-flexible mt-5">
  <h2>Flexible for Any Public Adjuster,<br>at Any Stage</h2>
  <p>
    Whether you are operating independently, forming a small team, or expanding a <br>dynamic business,
    Claim Compass adapts to your claims management style.
  </p>
  <strong>All the essentials to move your workflow forward.</strong>

  <div class="slider-wrapper"><div class="slider-track-overlay"></div>
    <div class="slider-track"><?php if(isset($slides)&&is_array($slides)){ for($s=0;$s<2;$s++){ foreach($slides as $slide){ ?>
      <div class="slide-card">
        <img src="<?=$slide['IMAGE'];?>" alt="<?=$slide['HEAD'];?> | <?=env('APP_NAME');?>"/>
        <h4><?=$slide['HEAD'];?></h4>
        <p><?=$slide['DESCRIPTION'];?></p>
      </div>
<?php }}} ?>
    </div>
  </div>

  <div class=" mt-4"><a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Sign up Today</a></div>
</section>



<!-- Testimonials -->
<section class="section testimonials">
  <h2>What Early Access Users Are Saying</h2>
  <div class="testimonial-cards">
    <div class="card">
      <div class="quote-icon"><img src="<?=base_url('assets/icons/quote.svg');?>" alt="Quotation | " width="50"/></div>
      <p>
        Finally, a CRM that actually understands how adjusters work. Claim Compass gives me clarity without extra noise.
      </p>
      <strong>Carlos M.</strong>
      <small>Independent Adjuster, Texas</small>
    </div>
    <div class="card">
      <div class="quote-icon"><img src="<?=base_url('assets/icons/quote.svg');?>" alt="Quotation | " width="50"/></div>
      <p>
        I stopped using spreadsheets on day one. The interface is clean, the claim views are smart, and nothing feels bloated.
      </p>
      <strong>Heather T.</strong>
      <small>Public Adjuster, Florida</small>
    </div>
    <div class="card">
      <div class="quote-icon"><img src="<?=base_url('assets/icons/quote.svg');?>" alt="Quotation | " width="50"/></div>
      <p>
        It just works. Claim Compass does exactly what I need it to do, without getting in my way. I can't wait for the full release.
      </p>
      <strong>Julian R.</strong>
      <small>Adjuster Team Lead, California</small>
    </div>
  </div>
</section>



<!-- Claim CRM -->
<section class="claim-crm-section">
  <div class="claim-crm-container">
    <!-- Left Content -->
    <div class="claim-crm-left">
      <h3>Claim Compass: Your claims <br/> CRM, done right</h3>
      <p class="subheadline"><strong>Your claims. Your flow. Your way.</strong></p>
      <p class="description">
        Experience a claims-focused Customer <br/> Relationship Management (CRM) system <br/> tailored for public adjusters. Designed to <br/> support your operational workflow, it delivers <br/> efficient tracking, seamless team <br/> coordination, intelligent automation, and <br/> future-ready integrations.
      </p>
    </div>

    <!-- Divider -->
    <div class="claim-crm-divider"></div>

    <!-- Right Content -->
    <div class="claim-crm-right">
      <h3>
        Get started today with Claim Compass. Simple, connected, and built to support your next move.
      </h3>
      <div class="text-right"><a href="https://claimcompasscrm.com/signup" target="_BLANK" class="btn-signup bs-theme">Sign up Today</a></div>
    </div>
  </div>
</section>




<?=$this->endSection();?>