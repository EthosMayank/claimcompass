<footer>
    <div class="footer-container">
      <div class="footer-logo">
        <img src="<?=base_url('assets/ClaimCompass Logo White.png');?>" alt="Logo" />
        <div class="footer-logo-text">
          <span class="footer-text">The CRM that keeps you on track.</span>
        </div>
      </div>
      <div class="footer-links">
        <a href="<?=base_url(route_to('home'));?>">Home</a>
        <span>|</span>
        <a href="<?=base_url(route_to('contact'));?>">Contact</a>
        <span>|</span>
        <a href="<?=base_url(route_to('faqs'));?>">FAQs</a>
      </div>
    </div>
  </footer>

