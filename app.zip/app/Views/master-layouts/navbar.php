<header>
    <div class="logo">
      <a href="<?=base_url(route_to('home'));?>">
        <img src="<?=base_url('assets/icons/logo.svg');?>" alt="" width="150"/>
      </a>
    </div>
    <nav>
      <a href="<?=base_url(route_to('home'));?>">Home</a>
      <a href="<?=base_url(route_to('contact'));?>">Contact</a>
      <a href="<?=base_url(route_to('faqs'));?>">FAQs</a>
    </nav>
    <div class="menu-toggle" onclick="toggleMenu()">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="mobile-nav" id="mobileNav">
      <a href="<?=base_url(route_to('home'));?>">Home</a>
      <a href="<?=base_url(route_to('contact'));?>">Contact</a>
      <a href="<?=base_url(route_to('faqs'));?>">FAQs</a>
    </div>
    <a class="btn bs-theme" href="https://claimcompasscrm.com/signup" target="_BLANK">Get Started</a>
  </header>