<!DOCTYPE html><html lang="en">
<head><meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?=$page_title??env('APP_NAME');?></title>
  <meta name="description" content="<?=$page_description??'Claim Compass is a powerful, simple-to-use CRM designed specifically for public adjusters. Track claims, automate workflows, and stay organized.'?>">
  <meta name="keywords" content="<?=$page_keywords??'Claim Management, Public Adjusters CRM, Insurance Claims, Workflow Automation, Adjuster Software, Claims Tracker';?>">
  <meta name="author" content="<?=env('APP_NAME')??'Radicle, Seedfist';?>">
  <link rel="canonical" href="<?=current_url();?>">

  <meta name="robots" content="<?=isset($page_meta[0])&&$page_meta[0]?'index':'noindex';?>, <?=isset($page_meta[1])&&$page_meta[1]?'follow':'nofollow';?>">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">

  <meta property="og:type" content="website">
  <meta property="og:url" content="<?=current_url();?>">
  <meta property="og:title" content="Claim Compass – CRM for Public Adjusters">
  <meta property="og:description" content="Simplify your claims process with automation, smart tracking, and full visibility for public adjusters.">
  <meta property="og:image" content="<?=base_url();?>/assets/img/og-image.jpg">


  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:url" content="https://www.claimcompass.com/">
  <meta name="twitter:title" content="Claim Compass – CRM for Public Adjusters">
  <meta name="twitter:description" content="Track claims, automate your workflow, and manage teams with Claim Compass CRM for adjusters.">
  <meta name="twitter:image" content="https://www.claimcompass.com/assets/img/twitter-card.jpg">


  <link rel="icon" type="image/png" href="<?=base_url();?>/assets/favicon.png">
  <link rel="apple-touch-icon" href="<?=base_url();?>/assets/apple-touch-icon.png">
  <link rel="manifest" href="<?= base_url('manifest.json') ?>">
  <meta name="theme-color" content="#e4fb81">



  <link href="<?=base_url('assets/css/style.css');?>?v=1.5" rel="stylesheet" preload/>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Claim Compass",
    "url": "<?php echo base_url();?>",
    "applicationCategory": "BusinessApplication",
    "operatingSystem": "Web",
    "description": "A CRM software tailored for public adjusters to manage insurance claims efficiently.",
    "creator": {
      "@type": "Organization",
      "name": "Claim Compass"
    }
  }
  </script>
  </head>
  <body>
    <?php require_once('navbar.php');?>


    <?=$this->renderSection('content');?>



    <?php require_once('footer.php');?>
    <?php require_once('scripts.php');?>
    </body>
</html>


