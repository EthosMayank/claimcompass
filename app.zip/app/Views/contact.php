<?php $page_data=['page_title'=>$page_title??env("APP_NAME"),'page_menu'=>$page_menu??false,'page_sidemenu'=>$page_sidemenu??false];$this->extend('master-layouts/main-section',$page_data); ?>
<?=$this->section('content') ?>

<div class="thank-you-popup" id="thankYouPopup">
  <div class="popup-content">
    <button class="close-btn icon-circle icon-bg-dark icon-transparent icon-pad" onclick="closePopup()">×</button>
    <h2>Thank you for reaching out!<br><span>We’ll follow up soon.</span></h2>
  </div>
</div>




<!-- Section 1: Intro -->
<section class="contact-intro mt-1">
  <h2>Smarter claims begin with the right <br/>CRM conversation</h2>
  <p class="mt-2">
    Now is the perfect time to switch or start your journey. Let’s<br/> explore how Claim Compass helps adjusters handle claims with<br/> clarity, less hassle, and the right tools from the beginning.
  </p>
  <strong>Start your free 2-week.<br>No pressure. Just progress.</strong>
  <div class="mt-4"><a href="#" class="btn bs-theme">Sign up Today</a></div>
</section>

<!-- Section 2: Contact Form -->
<section class="contact-form-wrapper mt-2">
  <div class="contact-form-card">
    <h3>Let’s Connect</h3>
    <p class="subtext mt-2">
      <strong><i>Do you have any questions before you start?</i></strong>
      Are you curious about how Claim Compass integrates with your current workflow? Reach out to us, we’d be<br/> excited to hear from you.
    </p>

    <form class="mt-2" method="POST" id="contact-form">
      <input type="text" placeholder="First name" name="name" required />
      <input type="email" placeholder="Email" name="email" required />
      <input type="text" placeholder="Role or Company" name="roleorcompany"/>
      <label for="message"><strong>Message:</strong></label>
      <textarea id="message" name="message" rows="5" placeholder="Write your message..."></textarea>
      <div class="mt-3 text-right"><button type="submit" class="form-btn btn bs-theme">Reach Out!</button></div>
    </form>
  </div>
</section>

<!-- Section 3: FAQ Promo -->
<section class="faq-promo mt-5 mb-6">
  <img src="<?=base_url('assets/img/Magnifying glass.png');?>" alt="FAQ icon" />
  <h3>Got Questions? We’ve Got Answers</h3>
  <p>
    Not quite ready to reach out? Our <strong><a href="<?=base_url(route_to('faqs'));?>">FAQ Page</a></strong> covers everything from onboarding to integrations and pricing.
  </p>
  <div class="mt-4"><a href="<?=base_url(route_to('faqs'));?>" class="cta-btn btn bs-theme mt-3">View FAQs</a></div>
</section>


<script>
  function showPopup() {
    document.getElementById("thankYouPopup").style.display = "flex";
  }

  function closePopup() {
    document.getElementById("thankYouPopup").style.display = "none";
  }

  // Example trigger (auto-show after form submission)
  // window.onload = showPopup;
</script>


<?=$this->endSection();?>