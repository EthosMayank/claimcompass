<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index',['as'=>'home']);
$routes->get('/faqs', 'Home::faqs',['as'=>'faqs']);
$routes->get('/contact', 'Home::contact',['as'=>'contact']);
$routes->post('/contact/send', 'Home::contactSubmit',['as'=>'contact.submit']);
